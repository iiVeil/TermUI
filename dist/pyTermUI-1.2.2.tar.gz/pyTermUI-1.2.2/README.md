# TermUI

TermUI is a rapid development user interface library for python command-line applications.

If you would like a reference for the library, D-Word is built on it. You can find it here: https://github.com/iiVeil/D-Word-Password-Manager

Complete documentation available at https://pytermui.readthedocs.io/en/latest/

# Version 1.2

All changelogs can be found in changelog.md on github